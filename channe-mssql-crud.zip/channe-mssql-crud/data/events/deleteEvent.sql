DELETE [dbo].[events]
WHERE [eventId]=@eventId

