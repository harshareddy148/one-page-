# spring-boot-security-jwt
Spring Boot JWT Authentication Example using Spring Security and Spring Data JPA
See explanation here- https://www.netjstech.com/2021/02/spring-boot-spring-security-jwt-authentication.html
