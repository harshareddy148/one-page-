package com.netjstech.model;

public enum Roles {
	ROLE_USER,
	ROLE_ADMIN
}
