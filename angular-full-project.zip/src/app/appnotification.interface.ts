export interface AppNotification {
    isError: boolean;
    message: string;
    location: string;
}